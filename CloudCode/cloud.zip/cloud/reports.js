/* global Parse */

var _ = require ('underscore');
var utils = require ('cloud/utils.js');

Parse.Cloud.define("instanceTargetReport", function(request, response) {

	var thisMonthString = request.params.thisMonthString;
	if (!thisMonthString)
	{
		var todayDate = new Date()
		thisMonthString = utils.recordDateString(todayDate).substring(0,7);
	}

	var responseData = [];

	// get unique staff types
	utils.getStaffTypes().then(function(staffTypes) {

		// do a count query on gridItems for all negative, all equal, and all positive results
		
		var staffCountPromises = [];

		var GridItem = Parse.Object.extend("GridItem");
		var Record = Parse.Object.extend("CensusRecord");

        _.each(staffTypes, function(staffType) {

			var responseObj = {};
			responseObj["staffTypeName"] = staffType;

			var recordQuery = new Parse.Query(Record);
			recordQuery.equalTo("status", "confirmed");
			recordQuery.startsWith("recordDateString", thisMonthString);

			// below instances
			var belowPromise = new Parse.Promise();
			var belowGridQuery = new Parse.Query(GridItem);
			belowGridQuery.equalTo("staffTypeName", staffType);
			belowGridQuery.lessThan("staffVariance", 0);
			belowGridQuery.matchesQuery("censusRecord", recordQuery);
			
			belowGridQuery.count().then(function(count) {
				responseObj["below"] = count;
				belowPromise.resolve();
			});

			staffCountPromises.push(belowPromise);

			// at instances
			var atPromise = new Parse.Promise();
			var atGridQuery = new Parse.Query(GridItem);
			atGridQuery.equalTo("staffTypeName", staffType);
			atGridQuery.equalTo("staffVariance", 0);
			atGridQuery.matchesQuery("censusRecord", recordQuery);
			
			atGridQuery.count().then(function(count) {
				responseObj["at"] = count;
				atPromise.resolve();
			});

			staffCountPromises.push(atPromise);

			// above instances
			var abovePromise = new Parse.Promise();
			var aboveGridQuery = new Parse.Query(GridItem);
			aboveGridQuery.equalTo("staffTypeName", staffType);
			aboveGridQuery.greaterThan("staffVariance", 0);
			aboveGridQuery.matchesQuery("censusRecord", recordQuery);
			
			aboveGridQuery.count().then(function(count) {
				responseObj["above"] = count;
				abovePromise.resolve();
			});

			responseData.push(responseObj);

			staffCountPromises.push(abovePromise);

		});

        return Parse.Promise.when(staffCountPromises);		

	}).done(function() {
        // return the facility
        response.success(responseData);
    }).fail(function(error) {
        // oh no!
        response.error(error);
    });
});