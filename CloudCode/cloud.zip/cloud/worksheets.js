/* global Parse */

var _ = require ('underscore');
var records = require('cloud/records.js');

Parse.Cloud.define("getWorksheet", function(request, response) {
  
     // pull in our request parameters
    var facilityId = request.params.facilityId;
    var time = request.params.time;
    var dateString = request.params.dateString;
    
    var Facility = Parse.Object.extend("Facility");
    var facility = new Facility();
    facility.id = facilityId;
    
    // For later
    var records = [];
     
    var query = new Parse.Query("Unit");
    query.equalTo("facility", facility);
    
    query.find().then(function(units) {
        var unitPromises = [];
        
        _.each(units, function(unit) {
            var promise = records.getRecordForTimestamp(unit, time, dateString).then(function(record) {
                return  record ? records.createRecordJSON(unit, record, 0) : undefined;
            }).then(function(json) {
                if (json != undefined)
                    records.push(json);
            });
            
            unitPromises.push(promise);
        });
        
        return Parse.Promise.when(unitPromises);
    }).then(function() {
        var query = new Parse.Query("StaffChange");
        query.equalTo("facility", facility);
        query.equalTo("recordDateString", dateString);
        query.equalTo("recordTime", time);
        query.include("fromUnit").include("toUnit");
        
        return query.find();
    }).done(function(changes) {
        response.success({
            "facilityId": facilityId,
            "records": records,
            "changes": changes,
            "recordDateString": dateString,
            "recordTime": time
        });
    }).fail(function(error) {
        response.error(error);
    });
});

Parse.Cloud.define("saveWorksheet", function(request, response) {
  
     // pull in our request parameters
    var facilityId = request.params.facilityId;
    var time = request.params.recordTime;
    var dateString = request.params.recordDateString;
    var changes = request.params.changes;
    
    var StaffChange = Parse.Object.extend("StaffChange");
    
    var Facility = Parse.Object.extend("Facility");
    var facility = new Facility();
    facility.id = facilityId;
    
    // For later
    var records = [];
     
    var query = new Parse.Query("StaffChange");
    query.equalTo("facility", facility);
    query.equalTo("recordDateString", dateString);
    query.equalTo("recordTime", time);
    
    query.find().then(function(changes) {
        return Parse.Object.destroyAll(changes);
    }).then(function() {
        var changeObjects = [];
        
        _.each(changes, function(change) {
            var staffChange = new StaffChange();
            staffChange.set("facility", facility);
            staffChange.set("staffTypeName", change.staffTypeName);
            staffChange.set("count", change.count);
            staffChange.set("fromUnit", change.fromUnit);
            staffChange.set("toUnit", change.toUnit);
            staffChange.set("recordDateString", dateString);
            staffChange.set("recordTime", time);
            
            changeObjects.push(staffChange);
        });
        
        return Parse.Object.saveAll(changeObjects);
    }).then(function() {
        var query = new Parse.Query("Unit");
        query.equalTo("facility", facility);
        
        return query.find();
    }).then(function(units) {
        var unitPromises = [];
        
        _.each(units, function(unit) {
            var promise = records.getRecordForTimestamp(unit, time, dateString).then(function(record) {
                if (record && record.get("status") == "saved") {
                    console.log("Adjusting record for " + record.get("unit").id)
                    record.set("status", "adjusted");
                
                    return record.save();
                } else {
                    return record;
                }
            }).then(function(record) {
                return  record ? records.createRecordJSON(unit, record, 0) : undefined;
            }).then(function(json) {
                if (json != undefined)
                    records.push(json);
            });
            
            unitPromises.push(promise);
        });
        
        return Parse.Promise.when(unitPromises);
    }).done(function() {
        response.success();
    }).fail(function(error) {
        response.error(error);
    });
});